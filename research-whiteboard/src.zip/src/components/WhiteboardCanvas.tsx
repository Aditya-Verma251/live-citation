import React, { useEffect, useState, useMemo } from "react";
import { Excalidraw } from "@excalidraw/excalidraw";
import { ExcalidrawImperativeAPI } from "@excalidraw/excalidraw/types/types";
import { generateExcalidrawElements } from "../utils/excalidrawAdapter";
import { ResearchPaperNode, ResearchPaperEdge } from "../types";

interface WhiteboardCanvasProps {
  paperNodes: ResearchPaperNode[];
  paperEdges: ResearchPaperEdge[];
  onSelectNode?: (nodeId: string | null) => void;
  onSelectEdge?: (edgeId: string | null) => void;
}

export const WhiteboardCanvas: React.FC<WhiteboardCanvasProps> = ({
  paperNodes,
  paperEdges,
  onSelectNode,
  onSelectEdge,
}) => {
  const [excalidrawAPI, setExcalidrawAPI] = useState<ExcalidrawImperativeAPI | null>(null);

  // Convert our app data to Excalidraw format
  const elements = useMemo(() => {
    return generateExcalidrawElements(paperNodes, paperEdges);
  }, [paperNodes, paperEdges]);

  // Push updates to the canvas dynamically when paperNodes/Edges change
  useEffect(() => {
    if (!excalidrawAPI) return;
    excalidrawAPI.updateScene({ elements });
  }, [elements, excalidrawAPI]);

  return (
    <div style={{ position: "absolute", top: 0, left: 0, right: 0, bottom: 0 }}>
      <Excalidraw
        excalidrawAPI={(api) => setExcalidrawAPI(api)}
        initialData={{
          elements: elements,
          appState: { viewBackgroundColor: "#f5f6f8" },
        }}
        onChange={(excalElements, appState) => {
          // Detect selection to open the Inspector panel in App.tsx
          const selectedIds = Object.keys(appState.selectedElementIds).filter(
            (id) => appState.selectedElementIds[id]
          );
          
          if (selectedIds.length === 1) {
            const selectedId = selectedIds[0];
            // Remove the "-text" suffix if the user clicks the title text instead of the box
            const baseId = selectedId.replace('-text', ''); 
            
            if (paperNodes.some((n) => n.id === baseId)) {
              if (onSelectNode) onSelectNode(baseId);
              if (onSelectEdge) onSelectEdge(null);
            } else if (paperEdges.some((e) => e.id === baseId)) {
              if (onSelectEdge) onSelectEdge(baseId);
              if (onSelectNode) onSelectNode(null);
            }
          } else {
             if (onSelectNode) onSelectNode(null);
             if (onSelectEdge) onSelectEdge(null);
          }
        }}
      />
    </div>
  );
};