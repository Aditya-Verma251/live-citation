import React, { useMemo } from "react";
import { Excalidraw } from "@excalidraw/excalidraw";
import { generateExcalidrawElements } from "../utils/excalidrawAdapter";
import { initialPapers, initialLinks } from "../data/initialData"; // Or fetch from linkedPapersData.ts

const WhiteboardCanvas: React.FC = () => {
  const elements = useMemo(() => {
    return generateExcalidrawElements(initialPapers, initialLinks);
  }, []);

  return (
    <div style={{ width: "100%", height: "100vh", border: "1px solid #ccc" }}>
      <Excalidraw
        initialData={{
          elements: elements,
          appState: { viewBackgroundColor: "#f5f6f8" },
        }}
      />
    </div>
  );
};

export default WhiteboardCanvas;