import { ExcalidrawElement } from "@excalidraw/excalidraw/types/element/types";
import { Paper, Link } from "../types"; // Adjust based on your types.ts

export const generateExcalidrawElements = (
  papers: Paper[],
  links: Link[]
): ExcalidrawElement[] => {
  const elements: ExcalidrawElement[] = [];

  // Generate Nodes (Research Paper Cards)
  papers.forEach((paper, index) => {
    const x = index * 300; 
    const y = index * 150; 

    // Container Rectangle
    elements.push({
      id: paper.id,
      type: "rectangle",
      x,
      y,
      width: 250,
      height: 100,
      strokeColor: "#1e1e1e",
      backgroundColor: "#f8f9fa",
      fillStyle: "solid",
      strokeWidth: 2,
      roughness: 0,
      roundness: { type: 3 },
      groupIds: [paper.id],
    } as ExcalidrawElement);

    // Paper Metadata (Title)
    elements.push({
      id: `${paper.id}-text`,
      type: "text",
      x: x + 10,
      y: y + 10,
      width: 230,
      height: 80,
      text: paper.title,
      fontSize: 16,
      fontFamily: 1,
      textAlign: "left",
      verticalAlign: "top",
      strokeColor: "#000000",
      groupIds: [paper.id],
    } as ExcalidrawElement);
  });

  // Generate Edges (Connections)
  links.forEach((link) => {
    const sourceNode = elements.find((el) => el.id === link.sourceId);
    const targetNode = elements.find((el) => el.id === link.targetId);

    if (sourceNode && targetNode) {
      elements.push({
        id: `${link.sourceId}-${link.targetId}`,
        type: "arrow",
        x: sourceNode.x + sourceNode.width / 2,
        y: sourceNode.y + sourceNode.height / 2,
        width: targetNode.x - sourceNode.x,
        height: targetNode.y - sourceNode.y,
        strokeColor: "#868e96",
        strokeWidth: 2,
        roughness: 1,
        points: [
          [0, 0],
          [targetNode.x - sourceNode.x, targetNode.y - sourceNode.y],
        ],
        startBinding: { elementId: sourceNode.id, focus: 0, gap: 10 },
        endBinding: { elementId: targetNode.id, focus: 0, gap: 10 },
      } as ExcalidrawElement);
    }
  });

  return elements;
};